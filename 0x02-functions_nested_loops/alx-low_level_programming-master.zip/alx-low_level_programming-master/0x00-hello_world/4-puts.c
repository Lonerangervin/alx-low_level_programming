#include <stdio.h>
/**
 *main - entry point
 *Return: 0 always
 */
int main(void)
{
puts("\"Programming is like building a multilingual puzzle");
return (0);
}

