my first c programming language assigments
