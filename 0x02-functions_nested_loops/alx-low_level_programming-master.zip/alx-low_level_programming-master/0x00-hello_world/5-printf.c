#include <stdio.h>
/**
 * main - entry point
 * Return: 0 always
 */
int main(void)
{
printf("with proper grammar, but the outcome is a piece of art,\n");
return (0);
}
