#include <stdio.h>
#include <stdlib.h>
#include <time.h>
/**
 * main - Entry point
 *
 * Return: 0
 */
int main(void)
{
	char now;

	for (now = 'a'; now <= 'z'; now++)
		putchar(now);
	printf("\n");

		return (0);
}
