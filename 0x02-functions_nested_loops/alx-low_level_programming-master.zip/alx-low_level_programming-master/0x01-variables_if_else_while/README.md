read me for c variables if, else if and while
