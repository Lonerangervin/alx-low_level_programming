#include "main.h"
/**
 * print_alphabet  - This prints the alphabet a - z
 */
void print_alphabet(void)
{
char i = 'a';
while (i <= 'z')
{
_putchar(i);
i++;
}
_putchar('\n');
}
