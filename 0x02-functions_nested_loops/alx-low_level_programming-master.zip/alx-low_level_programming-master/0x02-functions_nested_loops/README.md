nested loop functions
